class Comment < ActiveRecord::Base

  validates_presence_of :email
  validates_presence_of :body
  validates_format_of :email, :with => /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\Z/i

  belongs_to :article, :foreign_key => "article_id"
  before_save :date_comment

  def date_comment
    comment_date = Time.now
  end

end
